
import { GoogleGenAI } from "@google/genai";
import { ImageSettings } from '../types';

export const generateImage = async (settings: ImageSettings): Promise<{ imageUrl: string; textResponse: string | null }> => {
  // Create a new instance for each call to ensure the latest API key is used.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const config: any = {
    imageConfig: {
      aspectRatio: settings.aspectRatio,
    },
  };

  if (settings.model === 'gemini-3-pro-image-preview') {
    config.imageConfig.imageSize = settings.imageSize;
    if (settings.useSearch) {
      config.tools = [{ googleSearch: {} }];
    }
  }

  try {
    const parts: any[] = [];

    if (settings.inputImage) {
      parts.push({
        inlineData: {
          mimeType: settings.inputImage.mimeType,
          data: settings.inputImage.base64,
        },
      });
    }

    // Always add a text part, even if it's empty for image-only prompts.
    parts.push({ text: settings.prompt || '' });


    const response = await ai.models.generateContent({
      model: settings.model,
      contents: { parts },
      config: config,
    });

    if (!response.candidates || response.candidates.length === 0) {
      throw new Error("No candidates returned from the API.");
    }

    const candidate = response.candidates[0];
    let imageUrl: string | null = null;
    let textResponse: string | null = null;

    for (const part of candidate.content.parts) {
      if (part.inlineData) {
        const base64Data = part.inlineData.data;
        imageUrl = `data:${part.inlineData.mimeType};base64,${base64Data}`;
      } else if (part.text) {
        textResponse = part.text;
      }
    }

    if (!imageUrl) {
      throw new Error("API response did not contain an image.");
    }
    
    return { imageUrl, textResponse };
  } catch (error) {
    console.error("Gemini API call failed:", error);
    throw error;
  }
};
