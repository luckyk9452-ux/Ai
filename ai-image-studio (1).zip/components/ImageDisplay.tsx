
import React from 'react';
import LoaderIcon from './icons/LoaderIcon';
import SparklesIcon from './icons/SparklesIcon';

interface ImageDisplayProps {
  image: { src: string; prompt: string } | null;
  isLoading: boolean;
  error: string | null;
}

const ImageDisplay: React.FC<ImageDisplayProps> = ({ image, isLoading, error }) => {
  const WelcomeState = () => (
    <div className="text-center">
      <SparklesIcon className="w-16 h-16 text-indigo-400 mx-auto mb-4" />
      <h2 className="text-2xl font-bold text-white">Welcome to AI Image Studio</h2>
      <p className="text-gray-400 mt-2">Enter a prompt and adjust the settings to create your first image.</p>
    </div>
  );

  const LoadingState = () => (
    <div className="text-center">
      <LoaderIcon className="w-16 h-16 text-indigo-500 mx-auto mb-4" />
      <h2 className="text-2xl font-bold text-white">Generating Your Vision...</h2>
      <p className="text-gray-400 mt-2">The AI is working its magic. This may take a moment.</p>
    </div>
  );

  const ErrorState = () => (
    <div className="text-center bg-red-900/20 border border-red-500/50 p-6 rounded-lg">
      <h2 className="text-xl font-bold text-red-400">Generation Failed</h2>
      <p className="text-gray-300 mt-2 max-w-md mx-auto">{error}</p>
    </div>
  );

  const ImageResult = () => (
    image && (
      <div className="w-full h-full flex flex-col items-center justify-center space-y-4">
        <div className="w-full max-w-3xl aspect-square bg-black rounded-lg overflow-hidden shadow-2xl shadow-indigo-900/20">
            <img 
                src={image.src} 
                alt={image.prompt} 
                className="w-full h-full object-contain"
            />
        </div>
        <p className="text-sm text-gray-400 bg-gray-800/50 px-4 py-2 rounded-md max-w-3xl text-center">
          {image.prompt}
        </p>
      </div>
    )
  );


  return (
    <div className="flex-1 flex items-center justify-center bg-gray-800/30 rounded-lg p-4 relative overflow-auto">
      {isLoading && <LoadingState />}
      {!isLoading && error && <ErrorState />}
      {!isLoading && !error && !image && <WelcomeState />}
      {!isLoading && !error && image && <ImageResult />}
    </div>
  );
};

export default ImageDisplay;
