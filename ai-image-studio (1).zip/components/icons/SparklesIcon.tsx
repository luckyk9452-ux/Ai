
import React from 'react';

const SparklesIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
  >
    <path
      fillRule="evenodd"
      d="M9 4.5a.75.75 0 01.721.544l.813 2.846a3.75 3.75 0 002.846.813l2.846-.813a.75.75 0 01.976.976l-.813 2.846a3.75 3.75 0 00.813 2.846l2.846.813a.75.75 0 010 1.442l-2.846.813a3.75 3.75 0 00-.813 2.846l.813 2.846a.75.75 0 01-.976.976l-2.846-.813a3.75 3.75 0 00-2.846.813l-.813 2.846a.75.75 0 01-1.442 0l-.813-2.846a3.75 3.75 0 00-2.846-.813l-2.846.813a.75.75 0 01-.976-.976l.813-2.846a3.75 3.75 0 00-.813-2.846l-2.846-.813a.75.75 0 010-1.442l2.846-.813a3.75 3.75 0 00.813-2.846l-.813-2.846A.75.75 0 019 4.5z"
      clipRule="evenodd"
    />
  </svg>
);

export default SparklesIcon;
