
import React from 'react';
import { ImageSettings, ImageModel, AspectRatio, ImageSize } from '../types';
import SparklesIcon from './icons/SparklesIcon';
import SettingsIcon from './icons/SettingsIcon';
import PhotoIcon from './icons/PhotoIcon';
import XCircleIcon from './icons/XCircleIcon';


interface ControlsPanelProps {
  settings: ImageSettings;
  onSettingsChange: (newSettings: Partial<ImageSettings>) => void;
  onGenerate: () => void;
  isLoading: boolean;
  onModelChange: (model: ImageModel) => void;
}

const ControlsPanel: React.FC<ControlsPanelProps> = ({
  settings,
  onSettingsChange,
  onGenerate,
  isLoading,
  onModelChange,
}) => {
  const aspectRatios: AspectRatio[] = ['1:1', '16:9', '9:16', '4:3', '3:4'];
  const imageSizes: ImageSize[] = ['1K', '2K', '4K'];
  
  const isProModel = settings.model === ImageModel.PRO;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
            const dataUrl = reader.result as string;
            const base64 = dataUrl.split(',')[1];
            onSettingsChange({
                inputImage: {
                    dataUrl,
                    base64,
                    mimeType: file.type
                }
            });
        };
        reader.readAsDataURL(file);
    }
    e.target.value = '';
  };

  return (
    <aside className="w-full lg:w-96 bg-gray-900 border-r border-gray-700/50 p-6 flex flex-col space-y-6 lg:h-screen lg:overflow-y-auto">
      <div className="flex items-center space-x-3">
        <SparklesIcon className="w-8 h-8 text-indigo-400" />
        <h1 className="text-2xl font-bold tracking-tight text-white">AI Image Studio</h1>
      </div>

      <div>
        <label htmlFor="prompt" className="block text-sm font-medium text-gray-300 mb-2">Prompt</label>
        <textarea
          id="prompt"
          rows={5}
          className="w-full bg-gray-800 border border-gray-600 rounded-lg p-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out"
          placeholder="e.g., A cinematic shot of a raccoon astronaut commandeering a pirate ship, epic lighting"
          value={settings.prompt}
          onChange={(e) => onSettingsChange({ prompt: e.target.value })}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">Input Image (Optional)</label>
        {settings.inputImage ? (
          <div className="relative">
            <img src={settings.inputImage.dataUrl} alt="Input preview" className="rounded-lg w-full aspect-square object-cover" />
            <button
              onClick={() => onSettingsChange({ inputImage: null })}
              className="absolute top-2 right-2 bg-black/60 rounded-full p-1 text-white hover:bg-black/80 transition-colors"
              aria-label="Remove image"
            >
              <XCircleIcon className="w-6 h-6" />
            </button>
          </div>
        ) : (
          <div>
            <label htmlFor="file-upload" className="relative cursor-pointer bg-gray-800 rounded-lg border-2 border-dashed border-gray-600 flex flex-col justify-center items-center h-32 text-center hover:border-gray-500 transition">
              <PhotoIcon className="mx-auto h-10 w-10 text-gray-500" />
              <span className="mt-2 block text-sm font-medium text-gray-400">Upload an image</span>
            </label>
            <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/*" onChange={handleFileChange} />
          </div>
        )}
      </div>

      <button
        onClick={onGenerate}
        disabled={isLoading || (!settings.prompt.trim() && !settings.inputImage)}
        className="w-full flex justify-center items-center py-3 px-4 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-900 disabled:text-gray-400 disabled:cursor-not-allowed text-white font-semibold rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-indigo-500 transition duration-150 ease-in-out"
      >
        <SparklesIcon className="w-5 h-5 mr-2" />
        {isLoading ? 'Generating...' : 'Generate'}
      </button>

      <div className="border-t border-gray-700/50 pt-6 space-y-6">
        <div className="flex items-center space-x-3 text-lg font-semibold text-gray-200">
            <SettingsIcon className="w-6 h-6 text-gray-400" />
            <span>Settings</span>
        </div>
        
        <div>
          <label htmlFor="model" className="block text-sm font-medium text-gray-300 mb-2">Model</label>
          <select
            id="model"
            className="w-full bg-gray-800 border border-gray-600 rounded-lg p-3 text-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            value={settings.model}
            onChange={(e) => onModelChange(e.target.value as ImageModel)}
          >
            <option value={ImageModel.STANDARD}>Standard (Flash)</option>
            <option value={ImageModel.PRO}>Professional (High Quality)</option>
          </select>
          {isProModel && <p className="text-xs text-gray-400 mt-2">The Pro model requires an API key from a paid GCP project.</p>}
        </div>

        <div>
            <label htmlFor="aspectRatio" className="block text-sm font-medium text-gray-300 mb-2">Aspect Ratio</label>
            <div className="grid grid-cols-3 gap-2">
                {aspectRatios.map(ratio => (
                    <button
                        key={ratio}
                        onClick={() => onSettingsChange({ aspectRatio: ratio })}
                        className={`py-2 px-3 text-sm rounded-md transition ${settings.aspectRatio === ratio ? 'bg-indigo-500 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}
                    >
                        {ratio}
                    </button>
                ))}
            </div>
        </div>

        <div>
            <label htmlFor="imageSize" className={`block text-sm font-medium mb-2 ${isProModel ? 'text-gray-300' : 'text-gray-500'}`}>Image Size (Pro Only)</label>
            <div className="grid grid-cols-3 gap-2">
                {imageSizes.map(size => (
                    <button
                        key={size}
                        onClick={() => onSettingsChange({ imageSize: size })}
                        disabled={!isProModel}
                        className={`py-2 px-3 text-sm rounded-md transition ${settings.imageSize === size && isProModel ? 'bg-indigo-500 text-white' : 'bg-gray-700'} ${isProModel ? 'hover:bg-gray-600' : 'opacity-50 cursor-not-allowed'}`}
                    >
                        {size}
                    </button>
                ))}
            </div>
        </div>

        <div>
            <label className={`flex items-center space-x-3 ${isProModel ? 'cursor-pointer' : 'cursor-not-allowed'}`}>
                <input
                    type="checkbox"
                    checked={settings.useSearch}
                    disabled={!isProModel}
                    onChange={(e) => onSettingsChange({ useSearch: e.target.checked })}
                    className="h-4 w-4 rounded border-gray-500 bg-gray-700 text-indigo-600 focus:ring-indigo-500 disabled:opacity-50"
                />
                <span className={`text-sm font-medium ${isProModel ? 'text-gray-300' : 'text-gray-500'}`}>
                    Use Google Search (Pro Only)
                </span>
            </label>
            <p className={`text-xs mt-1 ${isProModel ? 'text-gray-400' : 'text-gray-500'}`}>Ground prompt with real-time info.</p>
        </div>

      </div>
    </aside>
  );
};

export default ControlsPanel;
