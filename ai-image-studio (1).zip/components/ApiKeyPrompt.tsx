
import React from 'react';

interface ApiKeyPromptProps {
  onSelectKey: () => void;
  onCancel: () => void;
}

const ApiKeyPrompt: React.FC<ApiKeyPromptProps> = ({ onSelectKey, onCancel }) => {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-800 border border-gray-700 rounded-lg shadow-xl p-8 max-w-lg w-full text-center">
        <h2 className="text-2xl font-bold text-white mb-4">Pro Model Requires API Key</h2>
        <p className="text-gray-300 mb-6">
          To use the high-quality Professional model, you must select an API key from a paid Google Cloud project.
          Please ensure you have set up billing for your project.
        </p>
        <div className="space-y-4">
          <button
            onClick={onSelectKey}
            className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg transition duration-150"
          >
            Select API Key
          </button>
          <a
            href="https://ai.google.dev/gemini-api/docs/billing"
            target="_blank"
            rel="noopener noreferrer"
            className="block text-sm text-indigo-400 hover:text-indigo-300"
          >
            Learn more about billing
          </a>
          <button
            onClick={onCancel}
            className="w-full py-2 px-4 bg-gray-700 hover:bg-gray-600 text-gray-200 font-medium rounded-lg transition duration-150"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default ApiKeyPrompt;
