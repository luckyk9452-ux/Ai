
import React from 'react';
import { HistoryItem } from '../types';
import HistoryIcon from './icons/HistoryIcon';

interface HistoryPanelProps {
  history: HistoryItem[];
  onSelect: (item: HistoryItem) => void;
}

const HistoryPanel: React.FC<HistoryPanelProps> = ({ history, onSelect }) => {
  return (
    <aside className="w-full lg:w-64 bg-gray-900 border-l border-gray-700/50 p-6 flex-col hidden lg:flex">
      <div className="flex items-center space-x-3 mb-6">
        <HistoryIcon className="w-6 h-6 text-gray-400" />
        <h2 className="text-xl font-semibold text-white">History</h2>
      </div>
      <div className="flex-1 overflow-y-auto -mr-4 pr-4">
        {history.length === 0 ? (
          <div className="text-center text-gray-500 mt-8">
            <p>Your generated images will appear here.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            {history.map(item => (
              <div
                key={item.id}
                className="relative aspect-square rounded-lg overflow-hidden group cursor-pointer"
                onClick={() => onSelect(item)}
              >
                <img
                  src={item.src}
                  alt={item.prompt}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-2">
                  <p className="text-white text-xs line-clamp-2">{item.prompt}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </aside>
  );
};

export default HistoryPanel;
